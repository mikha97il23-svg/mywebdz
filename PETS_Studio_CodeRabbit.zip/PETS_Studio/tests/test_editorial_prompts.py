import hashlib
import json
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import core
import editorial_prompts as prompts
import topic_engine
import workshop
import test_service


class EditorialPromptTests(unittest.TestCase):
    def test_task_contracts_date_and_voice(self):
        for task in prompts.TASKS:
            text=core.generation_prompt(task,core.empty_article(),'ПРОЕКТ')
            for value in (prompts.current_date(),'JSON','ПРОЕКТ'):self.assertIn(value,text)
        self.assertIn('45–70',prompts.foundation())
        self.assertIn('не добавляй нарочные ошибки',prompts.foundation().lower())
        self.assertIn('Минимального количества источников для черновика нет',prompts.foundation())

    def test_voice_has_one_editable_project_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=core.Store(Path(tmp)/'test.db')
            row=next(d for d in store.documents() if d['name']=='PETS / 02_VOICE.md')
            doc=store.document(row['id']);doc['content']='Мой новый редакционный голос — ТЕСТ';store.save_document(doc)
            text=core.generation_prompt('article',core.empty_article(),store.context())
            self.assertIn('Мой новый редакционный голос — ТЕСТ',text)
            self.assertNotIn('Не начинай с «в современном мире»',text)
            self.assertNotIn('Не начинай с «в современном мире»',core.DEFAULT_MASTER)

    def test_headline_hints_are_not_a_gate(self):
        a=core.empty_article();a.update(title='Особенности наблюдения',body='Автор описал обычное наблюдение.');a['gates'].update(facts=True,safety=True,rights=True)
        report=core.qc(a);self.assertTrue(report['headline_advice']);self.assertTrue(report['can_approve'])

    def test_real_metrics_one_record_and_window(self):
        rows=[{'title':'А','measurements':[{'window':'24h','impressions':100,'opens':5},{'window':'24h','impressions':200,'opens':16}]},{'title':'Б','measurements':[{'window':'7d','impressions':1000,'opens':900}]},{'title':'В','measurements':[{'window':'24h','impressions':100,'opens':10}]},{'title':'Г','measurements':[{'window':'24h','impressions':0,'opens':0}]}]
        result=prompts.performance_context(rows)
        self.assertEqual([r['title'] for r in result['examples']],['В','А']);self.assertEqual(result['examples'][1]['ctr'],8)
        self.assertIn('малые выборки',result['note']);self.assertEqual(prompts.performance_context([])['examples'],[])

    def test_bank_ids_and_winter_coverage(self):
        items=json.loads((core.BASE/'seed_topics.json').read_text());old=json.loads((core.BASE/'seed_topics_legacy.json').read_text())
        self.assertEqual(len(items),126);self.assertEqual(len({t['id'] for t in items}),126)
        self.assertTrue(all(a['id']==b['id'] and a['title_working']!=b['title_working'] for a,b in zip(items,old)))
        for month in (11,12,1,2):self.assertGreater(sum(month in t.get('season_months',[]) for t in items[78:]),10)
        self.assertTrue(all(t['status'] in ('DRAFT_IDEA','NEEDS_AUTHOR_STORY') for t in items))

    def test_migration_preserves_articles_custom_docs_and_topics(self):
        original=core.BASE/'data/studio.sqlite3';before=hashlib.sha256(original.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'test.db';shutil.copy2(original,path)
            with sqlite3.connect(path) as c:
                old_articles=c.execute('SELECT * FROM articles ORDER BY id').fetchall()
                c.execute("UPDATE topics SET data=? WHERE id='T001'",(json.dumps({'id':'T001','title_working':'Моя тема','rubric':'HOME','risk':'GREEN','promise':'Моя идея'}),))
                c.execute("INSERT INTO documents VALUES('custom','Мои правила','Мой собственный голос',1,'active')")
                c.execute("UPDATE documents SET content='Моя правка ядра',enabled=1 WHERE name='Версия 1.0 / 01_CORE.md'")
            store=core.Store(path)
            with store.con() as c:self.assertEqual([tuple(r) for r in c.execute('SELECT * FROM articles ORDER BY id')],old_articles)
            self.assertIn('Моя правка ядра',store.context());self.assertIn('Мой собственный голос',store.context())
            self.assertEqual(next(t for t in store.topics() if t['id']=='T001')['title_working'],'Моя тема')
            old=json.loads((core.BASE/'seed_topics_legacy.json').read_text())
            self.assertNotEqual(next(t for t in store.topics() if t['id']=='T002')['title_working'],old[1]['title_working'])
            self.assertEqual(len(core.Store(path).topics()),126)
        self.assertEqual(before,hashlib.sha256(original.read_bytes()).hexdigest())

    def test_customized_pack_not_reset_on_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'test.db';store=core.Store(path)
            row=next(d for d in store.documents() if d['name']=='PETS / 02_VOICE.md');doc=store.document(row['id']);doc.update(content='Собственный голос',enabled=False);store.save_document(doc)
            doc=core.Store(path).document(row['id']);self.assertFalse(doc['enabled']);self.assertEqual(doc['content'],'Собственный голос')

    def test_month_changes_priority(self):
        items=[{'id':'a','title_working':'Зимний маршрут с собакой','rubric':'WALK','season_months':[1]},{'id':'b','title_working':'Ноябрьский маршрут с собакой','rubric':'WALK','season_months':[11]}]
        with patch('editorial_prompts.dt.datetime') as clock:
            clock.now.return_value.month=11;self.assertEqual(workshop.topic_suggestions('',items,[])['topics'][0]['id'],'b')
            clock.now.return_value.month=1;self.assertEqual(workshop.topic_suggestions('',items,[])['topics'][0]['id'],'a')

    def test_topic_prompt_has_niche_examples_and_feedback(self):
        text=topic_engine.prompt('Зима','МОЙ ПРОЕКТ',[],[],{'examples':[{'title':'МОЯ СТАТИСТИКА','ctr':3.5}]})
        for value in (prompts.current_date(),'старшего возраста','Примеры подходов','МОЯ СТАТИСТИКА','МОЙ ПРОЕКТ'):self.assertIn(value,text)


class PromptHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):test_service.HTTPTests.setUpClass.__func__(cls)
    @classmethod
    def tearDownClass(cls):test_service.HTTPTests.tearDownClass.__func__(cls)
    req=test_service.HTTPTests.req

    def test_metrics_reach_provider(self):
        a=core.empty_article();a.update(title='Моя статья с измерениями',measurements=[{'window':'24h','impressions':500,'opens':25}]);self.store.save(None,a)
        with patch('app.call_provider',return_value={'titles':['Проверочный заголовок']}) as provider:
            with self.req('/api/generate',{'mode':'ai','task':'titles','data':core.empty_article()}) as response:self.assertIn('titles',json.load(response)['result'])
            text=provider.call_args.args[2];self.assertIn('Моя статья с измерениями',text);self.assertIn('"ctr": 5.0',text)
