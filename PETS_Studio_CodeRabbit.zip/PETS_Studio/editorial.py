"""Editorial tools: deterministic local methods, never a demand or plagiarism oracle."""
import collections, datetime as dt, math, re
BRIEF_KEYS=('reader_problem','angle','promise','new_value','demand_evidence','author_contribution','experiment','learning')
RUBRICS={'HOME':'Дом и привычки','BEHAVIOR':'Поведение','WALK':'Прогулки','CARE':'Уход и возраст','CHOICE':'Выбор без рекламы','STORY':'Истории и опыт'}
def empty_brief():return {**{k:'' for k in BRIEF_KEYS},'rubric':'HOME','demand_status':'hypothesis'}
def validate_brief(v):
 if not isinstance(v,dict):raise ValueError('Редакционный замысел должен быть объектом.')
 b=empty_brief()
 for k in BRIEF_KEYS:
  if not isinstance(v.get(k,''),str) or len(v.get(k,''))>15000:raise ValueError('Некорректное поле замысла.')
  b[k]=v.get(k,'')
 b['rubric']=v.get('rubric','HOME');b['demand_status']=v.get('demand_status','hypothesis')
 if b['rubric'] not in RUBRICS or b['demand_status'] not in ('hypothesis','observed','tested'):raise ValueError('Некорректный статус замысла.')
 return b
FIELDS=('impressions','opens','completions','subscribers')
def measurements(v):
 if not isinstance(v,list) or len(v)>40:raise ValueError('До 40 срезов статистики на материал.')
 out=[]
 for row in v:
  if not isinstance(row,dict):raise ValueError('Некорректная статистика.')
  x={'window':row.get('window','24h'),'recorded_on':str(row.get('recorded_on',''))[:30],'note':str(row.get('note',''))[:3000]}
  if x['window'] not in ('24h','72h','7d','other'):raise ValueError('Некорректное окно наблюдения.')
  if x['recorded_on']:
   date=dt.date.fromisoformat(x['recorded_on'])
   if date>dt.datetime.now(dt.timezone.utc).date():raise ValueError('Дата среза не может быть в будущем.')
  for k in FIELDS:
   z=row.get(k)
   if z in ('',None):x[k]=None
   elif isinstance(z,bool) or not isinstance(z,int) or not 0<=z<=10**12:raise ValueError('Счётчики должны быть неотрицательными целыми числами.')
   else:x[k]=z
  if x['impressions'] is not None and x['opens'] is not None and x['opens']>x['impressions']:raise ValueError('Открытий больше показов: проверьте одинаковые фильтры, окно и источник. Не смешивайте весь трафик с показами карточки.')
  if x['completions'] is not None and x['opens'] is not None and x['completions']>x['opens']:raise ValueError('Дочитываний больше открытий: проверьте определения и окно.')
  out.append(x)
 return out

def rates(row):
 def ratio(a,b):return round(row[a]/row[b]*100,2) if row.get(a) is not None and row.get(b) not in (None,0) else None
 return {'ctr':ratio('opens','impressions'),'completion_rate':ratio('completions','opens')}

def tokens(s):return re.findall(r'[а-яёa-z0-9]+',s.lower().replace('ё','е'))
def shingles(s,n=5):
 t=tokens(s);return {tuple(t[i:i+n]) for i in range(max(0,len(t)-n+1))}
def similarity(article,others):
 base=shingles(article.get('body',''));head=set(tokens(article.get('title','')+' '+article.get('topic','')));results=[]
 paragraphs=[' '.join(p.split()) for p in article.get('body','').split('\n\n') if len(p.strip())>90]
 for other in others:
  a=other['data'];body=shingles(a.get('body',''));h=set(tokens(a.get('title','')+' '+a.get('topic','')))
  common=len(base&body);union=len(base|body);score=common/union if union else 0;theme=len(head&h)/len(head|h) if head|h else 0
  exact=[p[:320] for p in paragraphs if p.lower() in ' '.join(a.get('body','').lower().split())]
  if score>=.025 or theme>=.28 or exact:results.append({'id':other['id'],'title':a.get('title',''),'body_overlap':round(score*100,1),'topic_overlap':round(theme*100,1),'exact_fragments':exact[:3]})
 return {'matches':sorted(results,key=lambda r:(r['body_overlap'],len(r['exact_fragments']),r['topic_overlap']),reverse=True)[:6],'scope':'Лексическое сходство пятисловных фрагментов (Jaccard) и слов темы только внутри вашей базы. Не семантическая экспертиза, не интернет-антиплагиат и не процент уникальности. Пустые и слишком короткие тексты не оцениваются по телу.'}

def diagnostics(a):
 text=a.get('body','');title=a.get('title','');paragraphs=[p for p in text.split('\n\n') if p.strip()];messages=[]
 if len(title)>110:messages.append('Заголовок длинный: проверьте обрезку на карточке. 110 — редакционный ориентир, не лимит Дзена.')
 generic=('в этой статье мы','в современном мире','каждый владелец знает','не секрет, что','подведём итоги')
 found=[w for w in generic if w in text.lower()]
 if found:messages.append('Возможные шаблонные связки: '+', '.join(found)+'. Проверьте, добавляют ли они смысл.')
 if a.get('brief',{}).get('demand_status')!='hypothesis' and not a.get('brief',{}).get('demand_evidence','').strip():messages.append('Статус спроса отмечен, но основание не записано. Это не подтверждённый сигнал.')
 if len(paragraphs)>1 and len(paragraphs[0])>600:messages.append('Длинный первый абзац: обещание и узнаваемую ситуацию стоит показать раньше.')
 numbers=re.findall(r'\b\d+\s*%',text)
 if numbers:messages.append('Числа в процентах требуют опоры: '+', '.join(numbers[:6])+'. Машина не подтверждает их истинность.')
 return {'notes':messages,'scope':'Редакторские подсказки, не автоматический приговор. Отсутствие подсказок не означает высокое качество.'}
