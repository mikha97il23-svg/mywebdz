'use strict';
const CR={seq:0,jobs:[],timer:null,submitting:false,pending:null};
const CR_NAMES={article:'Черновик',rewrite:'Редактура',titles:'Заголовки',keywords:'Ключевые фразы',outline:'План',review:'Разбор'};
const CR_STATUS={prepared:'Готово к отправке',uncertain:'Отправка не подтверждена',queued:'В очереди',running:'В работе',needs_attention:'Нужен ваш ответ',ready:'Ответ готов',hold:'Нужна проверка',failed:'Задание остановлено',invalid_result:'Неподдерживаемый ответ',applied:'Применено'};
function codeRabbitMode(){return $('generation-mode').value==='coderabbit';}
function codeRabbitPreferred(){const c=S.boot?.coderabbit;return c?.configured&&c.consent&&c.preferred;}
function renderCodeRabbitConfig(){
 const c=S.boot.coderabbit||{};
 $('cr-region').value=c.region||'us';$('cr-repository').value=c.repository||'';$('cr-branch').value=c.branch||'main';$('cr-key').value='';
 $('cr-remember').checked=!!c.remember_key;$('cr-consent').checked=!!c.consent;$('cr-preferred').checked=!!c.preferred;
 $('cr-badge').textContent=c.configured?'Ключ сохранён · доступ проверяется отдельно':'Не подключён';
 $('cr-badge').className='badge '+(c.configured?'neutral':'warn');
 $('cr-keys-link').href=(c.region==='eu'?'https://app.eu.coderabbit.ai':'https://app.coderabbit.ai')+'/settings/api-keys';
}
function updateCodeRabbitMode(){
 const enabled=codeRabbitMode();$('cr-editor').hidden=!enabled;
 $('include-visuals').disabled=enabled;
 $('mode-note').textContent=enabled?'Задание выполняется в CodeRabbit. Можно продолжать работу; ответ применяется отдельно.':$('generation-mode').value==='ai'?'Текст и активные файлы отправляются выбранному провайдеру. Запросы могут быть платными.':'Локальные инструменты без внешних запросов.';
}
async function saveCodeRabbit(forget=false){
 const v={region:$('cr-region').value,repository:$('cr-repository').value.trim(),branch:$('cr-branch').value.trim(),remember_key:$('cr-remember').checked,consent:$('cr-consent').checked,preferred:$('cr-preferred').checked,forget_key:forget};
 if($('cr-key').value)v.api_key=$('cr-key').value;
 const button=$('cr-save');button.disabled=true;
 try{const result=await api('/api/coderabbit/config',v);S.boot.coderabbit=result;renderCodeRabbitConfig();if(codeRabbitPreferred())$('generation-mode').value='coderabbit';updateCodeRabbitMode();$('cr-config-status').textContent=forget?'Ключ CodeRabbit удалён из памяти и локального файла.':'Настройки сохранены. Проверьте доступ к репозиторию.';return result;}
 finally{button.disabled=false;}
}
async function checkCodeRabbit(){
 const button=$('cr-check');button.disabled=true;
 try{await saveCodeRabbit();$('cr-config-status').textContent='Проверяю ключ и репозиторий…';const result=await api('/api/coderabbit/check',{});$('cr-config-status').textContent=result.message;$('cr-badge').textContent='Доступ к репозиторию проверен';$('cr-badge').className='badge good';}
 catch(e){$('cr-config-status').textContent='Проверка не пройдена: '+e.message;throw e;}
 finally{button.disabled=false;}
}
function crSchedule(id,seq){
 clearTimeout(CR.timer);
 if(S.item?.id!==id||seq!==CR.seq||!S.boot.coderabbit?.configured||!S.boot.coderabbit?.consent)return;
 const job=CR.jobs.find(j=>['queued','running'].includes(j.status));
 if(job)CR.timer=setTimeout(()=>pollCodeRabbit(job.id,id,seq).catch(e=>{if(S.item?.id===id&&seq===CR.seq){toast(e.message,true);crSchedule(id,seq);}}),12000);
}
async function loadCodeRabbitJobs(){
 clearTimeout(CR.timer);const seq=++CR.seq,id=S.item?.id;if(!id)return;
 CR.jobs=[];renderCodeRabbitJobs();
 const jobs=await api('/api/coderabbit/jobs?article_id='+encodeURIComponent(id));
 if(S.item?.id!==id||seq!==CR.seq)return;
 CR.jobs=jobs;renderCodeRabbitJobs();crSchedule(id,seq);
}
async function pollCodeRabbit(jobId,id=S.item?.id,seq=CR.seq){
 const job=await api('/api/coderabbit/poll',{id:jobId});
 if(S.item?.id!==id||seq!==CR.seq)return;
 CR.jobs=CR.jobs.map(x=>x.id===job.id?job:x);renderCodeRabbitJobs();crSchedule(id,seq);
}
async function codeRabbitAction(action,job){
 const id=S.item?.id,seq=CR.seq;clearTimeout(CR.timer);
 const result=await api('/api/coderabbit/'+action,{id:job.id});
 if(S.item?.id!==id||seq!==CR.seq)return;
 CR.jobs=CR.jobs.map(x=>x.id===result.id?result:x);renderCodeRabbitJobs();crSchedule(id,seq);
}
async function startCodeRabbit(task='article'){
 if(CR.submitting)return;
 if(!S.boot.coderabbit?.configured||!S.boot.coderabbit?.consent){await go('settings');$('coderabbit-settings').scrollIntoView({block:'start'});toast('Сохраните ключ CodeRabbit и разрешите передачу материалов.');return;}
 await save();const item=S.item,id=item.id;
 if(['article','outline','titles','keywords'].includes(task)&&!item.data.topic.trim()){toast('Сначала укажите тему статьи.',true);$('topic').focus();return;}
 if(['rewrite','review'].includes(task)&&!item.data.body.trim()){toast('Сначала добавьте текст статьи.',true);return;}
 if(!confirm('Отправить эту версию статьи, активные правила и источники CodeRabbit? Задание может расходовать оплачиваемые минуты. Ответ сохранится отдельно.'))return;
 // Keep the client ID across a lost local HTTP response. The server also stores
 // the exact request before sending it to CodeRabbit.
 const signature=JSON.stringify({id,revision:item.revision,task,note:$('cr-note').value});
 if(!CR.pending||CR.pending.signature!==signature)CR.pending={signature,id:crypto.randomUUID()};
 CR.submitting=true;
 try{const job=await api('/api/coderabbit/start',{article_id:id,revision:item.revision,task,client_id:CR.pending.id,note:$('cr-note').value});CR.pending=null;if(S.item?.id===id){await loadCodeRabbitJobs();$('cr-jobs').scrollIntoView({behavior:'smooth',block:'nearest'});}toast(job.message,job.status==='uncertain');}
 finally{CR.submitting=false;}
}
async function applyCodeRabbit(job,choice){
 if(S.item?.id!==job.article_id)throw Error('Откройте исходную статью перед применением ответа.');
 await save();
 if(!confirm('Применить ответ к исходной версии? Человеческие подтверждения будут сброшены, предыдущий текст останется в истории.'))return;
 const id=S.item.id,signature=JSON.stringify(formData());
 const item=await api('/api/coderabbit/apply',{id:job.id,choice});
 if(S.item?.id!==id)return;
 // A user may keep typing during the apply request. Keep their unsaved form;
 // advance only the revision so the next save is based on the applied draft.
 if(S.dirty||JSON.stringify(formData())!==signature){S.item.revision=item.revision;toast('Ответ применён в базе. Ваши новые правки остались в форме; сохраните их или откройте материал заново.');await loadCodeRabbitJobs();return;}
 fill(item);await refresh();await runQC();toast('Черновик сохранён. Проверьте текст перед выпуском.');
}
function renderCodeRabbitJobs(){
 const box=$('cr-jobs');if(!box)return;box.replaceChildren();
 for(const job of CR.jobs){
  const details=el('details',{class:'result-panel cr-job'});if(['queued','running','uncertain','needs_attention','ready','hold','invalid_result'].includes(job.status))details.open=true;
  details.append(el('summary',{text:'CodeRabbit · '+(CR_NAMES[job.task]||job.task)+' · '+(CR_STATUS[job.status]||job.status)}));
  details.append(el('p',{class:'small muted',text:job.message||''}));
  const actions=el('div',{class:'action-row'});
  if(job.url)actions.append(el('a',{class:'button',href:job.url,target:'_blank',rel:'noopener noreferrer',text:'Открыть задачу ↗'}));
  if(['queued','running'].includes(job.status))actions.append(el('button',{class:'button',text:'Проверить статус',onclick:protect(()=>pollCodeRabbit(job.id))}));
  if(['prepared','uncertain'].includes(job.status))actions.append(el('button',{class:'button',text:'Повторить отправку с тем же ID',onclick:protect(()=>codeRabbitAction('retry',job))}));
  if(['needs_attention','invalid_result','failed'].includes(job.status))actions.append(el('button',{class:'button',text:'Проверить после ответа в CodeRabbit',onclick:protect(()=>codeRabbitAction('resume',job))}));
  const r=job.result;
  if(r){
   const text=r.text||(r.titles||r.keywords||[]).join('\n');
   details.append(el('div',{class:'result-text',text}));
   if(r.guard?.issues?.length)details.append(el('p',{class:'small muted',text:r.guard.issues.map(x=>x.message).join(' ')}));
   actions.append(el('button',{class:'button',text:'Копировать ответ',onclick:()=>copy(text).catch(fail)}));
   if(job.status==='ready'&&['article','rewrite','keywords','outline'].includes(job.task))actions.append(el('button',{class:'primary',text:'Применить к статье',onclick:protect(()=>applyCodeRabbit(job))}));
   if(job.status==='ready'&&job.task==='titles')r.titles.forEach((title,i)=>details.append(el('button',{class:'result-item',text:'Выбрать: '+title,onclick:protect(()=>applyCodeRabbit(job,i))})));
  }
  details.append(actions);box.append(details);
 }
}
function initCodeRabbit(){
 $('cr-save').onclick=protect(()=>saveCodeRabbit());$('cr-check').onclick=protect(checkCodeRabbit);$('cr-forget').onclick=protect(()=>saveCodeRabbit(true));
 $('cr-region').addEventListener('change',()=>{$('cr-keys-link').href=($('cr-region').value==='eu'?'https://app.eu.coderabbit.ai':'https://app.coderabbit.ai')+'/settings/api-keys';});
 $('generation-mode').addEventListener('change',updateCodeRabbitMode);
 renderCodeRabbitConfig();if(codeRabbitPreferred())$('generation-mode').value='coderabbit';updateCodeRabbitMode();
}
