import tempfile
import unittest
from pathlib import Path
from core import Store


class MomentumTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name) / 'studio.sqlite3')

    def tearDown(self):
        self.tmp.cleanup()

    def test_article_action_is_idempotent_and_builds_constellation(self):
        first = self.store.motivation_action('focus', 'article-1')
        second = self.store.motivation_action('focus', 'article-1')
        self.assertTrue(first['awarded'])
        self.assertFalse(second['awarded'])
        m = self.store.settings()['motivation']
        self.assertEqual(m['sparks'], 1)
        self.assertTrue(m['constellations']['article-1']['focus'])
        self.assertEqual(len(m['events']), 1)

    def test_quality_actions_accumulate_signal_and_unlock(self):
        for action in ('focus', 'source', 'draft', 'qc', 'approval', 'publish', 'reflection'):
            self.store.motivation_action(action, 'article-2')
        m = self.store.settings()['motivation']
        self.assertEqual(m['sparks'], 13)
        self.assertEqual(m['signal'], 11)
        self.assertIn('Дополнительный шаблон', m['unlocks'])
        self.assertEqual(set(m['constellations']['article-2']), set(('focus', 'source', 'draft', 'qc', 'approval', 'publish', 'reflection')))

    def test_session_updates_streak_once_per_day(self):
        first = self.store.motivation_action('session')
        second = self.store.motivation_action('session')
        self.assertTrue(first['awarded'])
        self.assertFalse(second['awarded'])
        m = self.store.settings()['motivation']
        self.assertEqual(m['sessions_done'], 1)
        self.assertEqual(m['streak_days'], 1)
        self.assertEqual(m['best_streak'], 1)

    def test_settings_form_cannot_mint_sparks(self):
        self.store.motivation_action('focus', 'article-3')
        s = self.store.settings()
        s['motivation']['sparks'] = 99999
        s['motivation']['events'] = []
        saved = self.store.save_settings(s)
        self.assertEqual(saved['motivation']['sparks'], 1)
        self.assertEqual(len(saved['motivation']['events']), 1)


if __name__ == '__main__':
    unittest.main()
