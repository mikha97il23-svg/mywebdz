import copy,json,tempfile,unittest,urllib.error,hashlib
from pathlib import Path
from unittest.mock import patch
import core,workshop,detector,test_service
class WorkshopTests(unittest.TestCase):
 def setUp(self):self.a=core.empty_article();self.topics=json.loads((core.BASE/'seed_topics.json').read_text())
 def test_bank_existing_ids(self):self.assertTrue(all(t['id'] in {x['id'] for x in self.topics} for t in workshop.topic_suggestions('лежанка',self.topics,[])['topics']))
 def test_bank_relevant(self):self.assertIn('лежанк',workshop.topic_suggestions('лежанка',self.topics,[])['topics'][0]['title_working'].lower())
 def test_bank_diverse(self):r=workshop.topic_suggestions('',self.topics,[])['topics'];self.assertGreater(len({t['rubric'] for t in r}),1)
 def test_bank_empty(self):self.assertEqual(workshop.topic_suggestions('тема',[],[])['topics'],[])
 def test_bank_marks_used(self):t=self.topics[0];r=workshop.topic_suggestions(t['title_working'],self.topics,[{'title':t['title_working'],'topic':t['title_working']}]);self.assertTrue(next(x for x in r['topics'] if x['id']==t['id'])['already_used'])
 def test_no_invented_relevance(self):self.assertNotIn('probability',workshop.topic_suggestions('',self.topics,[]))
 def test_profile_puppy(self):self.a['topic']='Как приучить щенка';self.assertIn('щенков',workshop.profile(self.a)['audience'])
 def test_profile_senior(self):self.a['body']='Пожилая собака: спокойный уход и наблюдение. '*6;self.assertIn('пожилых',workshop.profile(self.a)['audience'])
 def test_profile_behavior(self):self.a['body']='Почему собака боится и лает в новой ситуации? '*6;self.assertEqual(workshop.profile(self.a)['format'],'Объяснение поведения')
 def test_profile_myth(self):self.a['topic']='Разбор мифа о прогулках';self.assertEqual(workshop.profile(self.a)['format'],'Разбор мифа')
 def test_profile_compare(self):self.a['topic']='Как выбрать и сравнить лежанки';self.assertEqual(workshop.profile(self.a)['format'],'Сравнение')
 def test_profile_body_priority(self):self.a.update(topic='Миф',body='Как выбрать и сравнить лежанки без лишней покупки. '*5);self.assertEqual(workshop.profile(self.a)['format'],'Сравнение')
 def test_age_beats_incidental_family(self):self.a['body']='Пожилая собака отдыхает рядом с семьёй. '*6;self.assertIn('пожилых',workshop.profile(self.a)['audience'])
 def test_lead_beats_incidental_behavior(self):self.a['body']='Как выбрать и сравнить лежанки. '+'Обычный вопрос владельца. '*30+'Иногда поведение меняется.';self.assertEqual(workshop.profile(self.a)['format'],'Сравнение')
 def test_profile_no_age_guess(self):self.assertNotIn('45',workshop.profile(self.a)['audience'])
 def test_profile_explained(self):self.assertTrue(workshop.profile(self.a)['reasons'])
 def test_ai_profile_validation(self):self.assertRaises(ValueError,workshop.validate_profile,{'audience':'x','tone':'x','format':'несуществующий'})
 def test_ai_profile_good(self):self.assertEqual(workshop.validate_profile({'audience':'Владельцы','tone':'Живой','format':'Сравнение'})['mode'],'ai')
 def test_style_no_ai_percentage(self):r=workshop.style_audit('В современном мире важно отметить особенности собаки.');self.assertTrue(r['issues']);self.assertNotIn('probability',r);self.assertIn('не установлено',r['author_verdict'])
 def test_style_no_punctuation_accusation(self):self.assertFalse(workshop.style_audit('Собака — не человек.\n\nОбычный список: миска, поводок, лежанка.')['issues'])
 def test_style_empty(self):self.assertEqual(workshop.style_audit('')['status'],'Недостаточно текста')
 def test_style_hash(self):self.assertEqual(workshop.style_audit('abc')['content_hash'],hashlib.sha256(b'abc').hexdigest())
 def test_handoff_plain(self):self.assertTrue(workshop.parse_handoff('Текст статьи')['unstructured'])
 def test_handoff_json(self):self.assertEqual(workshop.parse_handoff('```json\n{"text":"тело","title":"заголовок"}\n```')['text'],'тело')
 def test_handoff_hold(self):self.assertTrue(workshop.parse_handoff('{"hold":true,"text":"нужны источники"}')['hold'])
 def test_handoff_reject_gates(self):self.assertRaises(ValueError,workshop.parse_handoff,'{"text":"body","gates":{"facts":true}}')
 def test_handoff_bad_keywords(self):self.assertRaises(ValueError,workshop.parse_handoff,'{"keywords":[1]}')
 def test_handoff_titles(self):self.assertEqual(len(workshop.parse_handoff('{"titles":["Один","Два"]}')['titles']),2)
 def test_handoff_profile_prompt(self):self.assertIn('audience',workshop.handoff_prompt(self.a,'profile','',{}))
 def test_detector_consent(self):self.assertRaises(ValueError,detector.check,'text '*100,None)
 def test_detector_length(self):self.assertRaises(ValueError,detector.check,'abc',{'consent':True})
 def test_detector_config_types(self):self.assertRaises(ValueError,detector.config,{'email':1,'key':2})
 def test_detector_config(self):self.assertEqual(detector.config({'email':'test@example.org','key':'TEST','consent':True})['key'],'TEST')
 def test_detector_adapter(self):
  with patch('detector.post',side_effect=[{'access_token':'TEST-TOKEN'},{'summary':{'ai':.4,'human':.6},'modelVersion':'TEST'}]) as req:
   r=detector.check('text '*100,{'email':'TEST','key':'TEST','consent':True},True);self.assertTrue(r['sandbox']);self.assertEqual(req.call_args_list[0].args[0],'https://id.copyleaks.com/v3/account/login/api');self.assertTrue(req.call_args.args[1]['sandbox']);self.assertEqual(req.call_args.args[1]['language'],'ru')
 def test_detector_bad_score(self):
  with patch('detector.post',side_effect=[{'access_token':'TEST'},{'summary':{'ai':99,'human':1}}]):self.assertRaises(ValueError,detector.check,'text '*100,{'email':'TEST','key':'TEST','consent':True})
 def test_detector_invalid_token(self):
  with patch('detector.post',return_value={'access_token':'TEST\nBAD'}):self.assertRaises(ValueError,detector.check,'text '*100,{'email':'TEST','key':'TEST','consent':True})
 def test_qc_contains_style(self):self.assertIn('style_audit',core.qc(self.a))
class WorkshopHTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):test_service.HTTPTests.setUpClass.__func__(cls)
 @classmethod
 def tearDownClass(cls):test_service.HTTPTests.tearDownClass.__func__(cls)
 req=test_service.HTTPTests.req
 def test_new_version(self):
  with self.req('/api/bootstrap') as r:self.assertIn('3.1',json.load(r)['version'])
 def test_topics(self):
  with self.req('/api/topic/suggest',{'query':'лежанка'}) as r:self.assertTrue(json.load(r)['topics'])
 def test_profile_local(self):
  with self.req('/api/profile',{'data':core.empty_article()}) as r:self.assertEqual(json.load(r)['mode'],'local')
 def test_profile_api_mock(self):
  with patch('app.call_provider',return_value={'audience':'Владельцы собак','tone':'Живой','format':'Сравнение'}) as provider:
   with self.req('/api/profile',{'data':core.empty_article(),'mode':'ai'}) as r:self.assertEqual(json.load(r)['mode'],'ai')
   self.assertTrue(provider.called)
 def test_profile_invalid_no_mutation(self):
  with patch('app.call_provider',return_value={'format':'BAD'}):
   with self.assertRaises(urllib.error.HTTPError):self.req('/api/profile',{'data':core.empty_article(),'mode':'ai'})
 def test_style(self):
  with self.req('/api/style',{'data':core.empty_article()}) as r:self.assertIn('scope',json.load(r))
 def test_handoff_route(self):
  with self.req('/api/handoff',{'data':core.empty_article(),'task':'profile'}) as r:self.assertIn('prompt',json.load(r))
 def test_parse_route(self):
  with self.req('/api/handoff/parse',{'text':'{"text":"hello"}'}) as r:self.assertEqual(json.load(r)['text'],'hello')
 def test_detector_secret_ephemeral(self):
  with self.req('/api/detector/config',{'email':'test@example.org','key':'DETECTOR-TEST-SECRET','consent':True}) as r:self.assertTrue(json.load(r)['configured'])
  with self.req('/api/backup') as r:self.assertNotIn('DETECTOR-TEST-SECRET',r.read().decode())
  self.assertNotIn(b'DETECTOR-TEST-SECRET',self.store.path.read_bytes())
  with self.req('/api/detector/config',{'forget':True}) as r:self.assertFalse(json.load(r)['configured'])
 def test_detector_missing_no_request(self):
  self.server.detector_credentials=None
  with patch('detector.post') as request:
   a=core.empty_article();a['body']='text '*100
   with self.assertRaises(urllib.error.HTTPError):self.req('/api/detector/check',{'data':a})
   request.assert_not_called()
 def test_new_assets(self):
  for path in ('/workshop.css','/workshop.js'):
   with self.req(path) as r:self.assertGreater(len(r.read()),100)
