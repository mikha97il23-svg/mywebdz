import http.client
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

import core
import notion_sync
import review_assistant
from app import AppServer


def ready_article():
    a = core.empty_article()
    a['title'] = 'Проверка условий отдыха'
    a['body'] = '\n\n'.join(f'Раздел {i}. ' + ('Практическое наблюдение для владельца собаки. ' * 7) for i in range(22))
    a['gates'].update(facts=True, safety=True, rights=True)
    return a


class ReviewWorkflowTests(unittest.TestCase):
    def test_three_human_confirmations_and_technical_checks_are_required(self):
        a = ready_article()
        self.assertTrue(core.qc(a)['can_approve'])
        for gate in core.REQUIRED_REVIEW_GATES:
            candidate = ready_article(); candidate['gates'][gate] = False
            self.assertFalse(core.qc(candidate)['can_approve'], gate)
        a['body'] += '\n\n[TODO]'
        self.assertFalse(core.qc(a)['can_approve'])

    def test_formatting_suggestions_and_optional_card_do_not_block(self):
        a = ready_article(); a['body'] = ('Очень длинный абзац. ' * 50) + '\n\n' + a['body'][1000:-100]
        a['body'] = a['body'][:7900] + ' «'
        a['claims'] = [{'anchor':'', 'url':'', 'excerpt':'', 'scope':'', 'checked_by':'', 'checked_on':'', 'verified':True}]
        report = core.qc(a)
        self.assertTrue(6000 <= report['characters'] <= 8000)
        self.assertTrue(any(x['code']=='PARAGRAPH' and x['excerpt'] for x in report['issues']))
        self.assertTrue(report['source_issues'])
        self.assertTrue(report['can_approve'])

    def test_explicitly_unverified_source_is_not_a_verified_fact(self):
        a = ready_article(); a['claims'] = [{'anchor':'', 'url':'', 'excerpt':'', 'scope':'', 'checked_by':'', 'checked_on':'', 'verified':False}]
        self.assertFalse(core.qc(a)['can_approve'])

    def test_technical_blockers_include_a_locatable_fragment(self):
        a = ready_article(); a['body'] += '\n\n[TODO]'
        issue = next(x for x in core.qc(a)['issues'] if x['code']=='PLACEHOLDER')
        self.assertEqual(issue['excerpt'], '[TODO]')
        a = ready_article(); a['body'] += '\n\n' + a['body'].split('\n\n')[0]
        issue = next(x for x in core.qc(a)['issues'] if x['code']=='REPEAT')
        self.assertIn(issue['excerpt'], a['body'])

    def test_clinical_and_expert_safety_remain_blocking(self):
        a = ready_article(); a['body'] += ' Давайте 5 мг/кг.'
        a['expert'] = {'name':'Врач','qualification':'ветеринар','evidence':'проверено'}
        self.assertFalse(core.qc(a)['can_approve'])
        self.assertTrue(any(x['code']=='CLINICAL' and x['excerpt'] for x in core.qc(a)['issues']))
        a = ready_article(); a['requires_expert'] = True
        self.assertFalse(core.qc(a)['can_approve'])
        a['expert'] = {'name':'Врач','qualification':'ветеринар','evidence':'проверено'}
        self.assertTrue(core.qc(a)['can_approve'])

    def test_em_dash_is_not_a_generation_blocker(self):
        a = ready_article()
        result = core.generation_guard('rewrite', {'text':a['body']+' —'}, a, {'min_chars':6000,'max_chars':8000})
        self.assertNotIn('EM_DASH', [item['code'] for item in result['guard']['issues']])

    def test_edit_invalidates_previous_confirmations_and_approval(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            article = ready_article(); article['gates']['originality'] = True
            item = store.save(None, article); store.approve(item['id'], item['revision'])
            changed = store.get(item['id']); changed['data']['body'] += '\n\nНовая фраза.'
            saved = store.save(item['id'], changed['data'], changed['revision'])
            self.assertIsNone(saved['approval'])
            self.assertTrue(saved['data']['gates']['originality'])
            self.assertFalse(saved['data']['gates']['facts'])
            self.assertFalse(saved['data']['gates']['safety'])
            self.assertTrue(saved['data']['gates']['rights'])
            with self.assertRaises(core.Problem):store.approve(item['id'], saved['revision'])

    def test_schedule_edit_keeps_confirmations(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            item = store.save(None, ready_article()); data = item['data']; data['plan_at'] = '2027-01-01T12:00'
            saved = store.save(item['id'], data, item['revision'])
            self.assertTrue(all(saved['data']['gates'][g] for g in core.REQUIRED_REVIEW_GATES))

    def test_notion_ready_status_follows_review_rules(self):
        a = ready_article()
        self.assertEqual(notion_sync.article_properties(a)['Статус']['status']['name'], 'Готово')
        a['gates']['facts'] = False
        self.assertEqual(notion_sync.article_properties(a)['Статус']['status']['name'], 'В работе')
        a['gates']['facts'] = True
        self.assertEqual(notion_sync.article_properties(a,settings={'min_chars':100,'max_chars':200})['Статус']['status']['name'], 'Готово')

    def test_notion_length_advice_does_not_push_unchanged_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            for existing in store.list_articles():store.delete(existing['id'])
            item = store.save(None, ready_article()); page_id = 'a' * 32
            store.set_notion_meta(item['id'], {'page_id':page_id, 'last_edited_time':'1', 'last_synced_fingerprint':core.fingerprint(item['data'])})
            store.save_settings({'min_chars':100,'max_chars':200})
            page={'id':page_id,'last_edited_time':'1','properties':{'Статус':{'type':'status','status':{'name':'Готово'}}}}
            with patch('notion_sync.query',return_value=[page]), patch('notion_sync._api',side_effect=AssertionError('unexpected network')), patch('notion_sync._update_page',return_value={'last_edited_time':'2'}) as update:
                result=notion_sync.sync(store,'test','https://app.notion.com/p/'+'b'*32,'sync')
            self.assertEqual(result['pushed'],0); update.assert_not_called()

    def test_notion_remote_only_edit_does_not_become_a_false_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            for existing in store.list_articles():store.delete(existing['id'])
            item = store.save(None, ready_article()); page_id = 'a' * 32
            store.set_notion_meta(item['id'], {'page_id':page_id, 'last_edited_time':'1', 'last_synced_fingerprint':core.fingerprint(item['data'])})
            page={'id':page_id,'last_edited_time':'2','properties':{'Статус':{'type':'status','status':{'name':'В работе'}}}}
            with patch('notion_sync.query',return_value=[page]), patch('notion_sync._read_blocks',return_value='обновлено в Notion'), patch('notion_sync._api',side_effect=AssertionError('unexpected network')):
                result=notion_sync.sync(store,'test','https://app.notion.com/p/'+'b'*32,'sync')
            self.assertEqual(result['pulled'],1); self.assertEqual(result['conflicts'],[])

    def test_ai_requires_literal_snippet_and_never_sets_approval(self):
        a = ready_article(); quote = a['body'][:40]
        raw = {'findings':[{'quote':quote, 'issue':'Нужна проверка', 'action':'Проверить источник', 'query':'собака отдых'}], 'verified':True}
        result = review_assistant.validate_review(raw, a)
        self.assertEqual(result['findings'][0]['quote'], quote)
        self.assertNotIn('verified', result)
        raw['findings'][0]['quote'] = 'Несуществующая цитата'
        with self.assertRaises(core.Problem):review_assistant.validate_review(raw, a)
        with self.assertRaises(core.Problem):review_assistant.validate_review({'text':'не JSON'}, a)

    def test_search_returns_only_safe_result_links_with_clear_limits(self):
        items = [{'title':'Результат', 'link':'https://example.org/article', 'description':'сниппет', 'published':''},
                 {'title':'Вредный', 'link':'javascript:alert(1)', 'description':'', 'published':''}]
        with patch('workshop.current_topic_research', return_value={'items':items,'source':'test'}):
            result = review_assistant.search_sources('проверка факта')
        self.assertEqual(len(result['results']), 1)
        self.assertIn('не проверенные доказательства', result['scope'])


class ReviewHTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.store = core.Store(Path(self.tmp.name)/'studio.sqlite3')
        self.server = AppServer(('127.0.0.1', 0), self.store)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.base = 'http://127.0.0.1:' + str(self.server.server_port)
    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(); self.tmp.cleanup()
    def post(self, path, data):
        req = urllib.request.Request(self.base+path, json.dumps(data).encode(), {'Content-Type':'application/json','X-Pets-CSRF':self.server.csrf})
        return urllib.request.urlopen(req, timeout=10)
    def test_ai_requires_consent_and_does_not_send_without_key(self):
        with patch('core.urllib.request.urlopen') as request:
            conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=10)
            try:
                conn.request('POST','/api/review/ai',json.dumps({'data':ready_article()}),{'Content-Type':'application/json','X-Pets-CSRF':self.server.csrf})
                response=conn.getresponse(); self.assertEqual(response.status,400); response.read(); request.assert_not_called()
            finally:conn.close()
    def test_review_and_search_return_untrusted_suggestions_only(self):
        a = ready_article(); quote = a['body'][:30]
        response = {'findings':[{'quote':quote,'issue':'Проверьте','action':'Откройте источник','query':'собака'}]}
        with patch('app.call_provider', return_value=response):
            with self.post('/api/review/ai', {'data':a}) as r:
                result=json.load(r)
                self.assertEqual(result['findings'][0]['quote'],quote)
                self.assertNotIn('can_approve',result)
        with patch('workshop.current_topic_research', return_value={'items':[],'source':'offline'}):
            with self.post('/api/review/sources', {'query':'собака'}) as r:self.assertEqual(json.load(r)['results'],[])
