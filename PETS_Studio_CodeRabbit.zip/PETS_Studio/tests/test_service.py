import copy,datetime as dt,io,json,sys,tempfile,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import core
from app import AppServer
class CoreTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=core.Store(Path(self.tmp.name)/'test.db');self.a=core.empty_article()
 def tearDown(self):self.tmp.cleanup()
 def good(self):
  self.a['title']='Проверяем место отдыха';self.a['body']='В этом примере есть свободный выход.\n\n'+'\n\n'.join(f'Наблюдение {i}: проверяем обычное расположение вещей, не делая неподтверждённых выводов о причинах поведения.' for i in range(62))
  self.a['claims']=[{'anchor':'В этом примере есть свободный выход.','url':'https://example.org/test','excerpt':'UNIT TEST ONLY','scope':'fixture only','checked_by':'TEST','checked_on':core.today(),'verified':True}]
  self.a['cover']={'description':'test','rightsholder':'TEST','evidence':'fixture only','verified':True};self.a['gates']={k:True for k in core.GATES};self.a['reviewer']='TEST';self.a['brief']['new_value']='TEST: самостоятельная польза';self.a['brief']['author_contribution']='TEST: ручная проверка и переработка';return self.a
 def test_seed(self):self.assertTrue(self.s.list_articles());self.assertGreater(len(self.s.documents()),1)
 def test_new(self):a=self.s.save(None,self.a);self.assertEqual(a['revision'],1)
 def test_revision(self):a=self.s.save(None,self.a);b=self.s.save(a['id'],self.a,1);self.assertEqual(b['revision'],2)
 def test_conflict(self):
  a=self.s.save(None,self.a);self.s.save(a['id'],self.a,1)
  with self.assertRaises(core.Problem):self.s.save(a['id'],self.a,1)
 def test_unicode(self):self.a['body']='А😀Б';self.assertEqual(core.qc(self.a)['characters'],3)
 def test_short(self):self.assertEqual(core.qc(self.a)['technical_status'],'BLOCK')
 def test_good(self):self.assertTrue(core.qc(self.good())['can_approve'])
 def test_pass_not_auto_approval(self):self.assertFalse(core.qc(self.good())['approval_current'])
 def test_missing_source_card_is_reported_but_optional(self):self.good();self.a['claims']=[];r=core.qc(self.a);self.assertTrue(r['source_issues']);self.assertTrue(r['can_approve'])
 def test_missing_anchor(self):self.good();self.a['claims'][0]['anchor']='NOT PRESENT';self.assertTrue(core.qc(self.a)['source_issues'])
 def test_invalid_url(self):self.good();self.a['claims'][0]['url']='javascript:alert(1)';self.assertTrue(core.qc(self.a)['source_issues'])
 def test_future_date(self):self.good();self.a['claims'][0]['checked_on']='2099-01-01';self.assertTrue(core.qc(self.a)['source_issues'])
 def test_unverified(self):self.good();self.a['claims'][0]['verified']=False;self.assertFalse(core.qc(self.a)['can_approve'])
 def test_placeholder(self):self.good();self.a['body']+=' [УТОЧНИТЬ]';self.assertTrue(any(i['code']=='PLACEHOLDER' for i in core.qc(self.a)['issues']))
 def test_repeat(self):self.good();self.a['body']+='\n\n'+self.a['body'].split('\n\n')[1];self.assertTrue(any(i['code']=='REPEAT' for i in core.qc(self.a)['issues']))
 def test_dash_ok(self):self.good();self.a['body']+='\n\nТире — допустимо, как и рекомендация обратиться к ветеринару.';self.assertEqual(core.qc(self.a)['technical_status'],'PASS')
 def test_dose_signal(self):self.good();self.a['body']+=' 5 мг/кг';r=core.qc(self.a);self.assertFalse(r['can_approve']);self.assertTrue(any(x['code']=='CLINICAL' for x in r['issues']))
 def test_rights_gate(self):self.good();self.a['gates']['rights']=False;self.assertFalse(core.qc(self.a)['can_approve'])
 def test_expert(self):self.good();self.a['requires_expert']=True;self.assertFalse(core.qc(self.a)['can_approve'])
 def test_approve_and_invalidate(self):
  a=self.s.save(None,self.good());self.s.approve(a['id'],1);self.assertTrue(self.s.check(a['id'])['approval_current']);self.a['title']='Новая версия';self.s.save(a['id'],self.a,1);self.assertFalse(self.s.check(a['id'])['approval_current'])
 def test_range_change_invalidates_approval(self):
  a=self.s.save(None,self.good());self.s.approve(a['id'],1);self.s.save_settings({'min_chars':100,'max_chars':200});self.assertFalse(self.s.get(a['id'])['approval']);self.assertFalse(any(x['approved'] for x in self.s.list_articles()))
 def test_delete(self):a=self.s.save(None,self.a);self.s.delete(a['id']);self.assertFalse(any(x['id']==a['id'] for x in self.s.list_articles()))
 def test_local_titles(self):self.assertEqual(len(core.local_titles('Собака и лежанка')),5)
 def test_keywords(self):self.assertIn('лежанка',core.keywords('Лежанка собаки. Лежанка и место отдыха.'))
 def test_context_limit(self):self.s.save_document({'name':'Большой','content':'x'*61000,'enabled':True});self.assertRaises(core.Problem,self.s.context)
 def test_backup_restore(self):b=self.s.backup();n=len(self.s.list_articles());r=self.s.restore(b);self.assertEqual(len(self.s.list_articles()),n+r['articles']);self.assertFalse(any(x['approved'] for x in self.s.list_articles()))
 def test_bad_backup_transaction(self):n=len(self.s.list_articles());self.assertRaises(core.Problem,self.s.restore,{'format':'wrong'});self.assertEqual(n,len(self.s.list_articles()))
 def test_settings_validation(self):self.assertRaises(core.Problem,self.s.save_settings,{'min_chars':8000,'max_chars':6000})
 def test_bad_provider(self):self.assertRaises(core.Problem,self.s.save_settings,{'provider':'arbitrary'})
 def test_no_key(self):self.assertRaises(core.Problem,core.call_provider,{'provider':'openai','model':'test','consent':True},'','hi')
 def test_no_consent(self):self.assertRaises(core.Problem,core.call_provider,{'provider':'openai','model':'test','consent':False},'TEST','hi')
 def test_provider_adapter(self):
  class Response:
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def read(self,*args):return json.dumps({'choices':[{'message':{'content':'{"titles":["Проверка"]}'}}]}).encode()
  with patch('core.urllib.request.urlopen',return_value=Response()) as req:
   r=core.call_provider({'provider':'openai','model':'TEST-MODEL','consent':True},'TEST-KEY','prompt');self.assertEqual(r['titles'],['Проверка']);self.assertEqual(req.call_args.args[0].full_url,'https://api.openai.com/v1/chat/completions')
 def test_anthropic_adapter(self):
  class Response:
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def read(self,*args):return json.dumps({'content':[{'type':'text','text':'{"keywords":["отдых собаки"]}'}]}).encode()
  with patch('core.urllib.request.urlopen',return_value=Response()) as req:
   r=core.call_provider({'provider':'anthropic','model':'TEST','consent':True},'TEST','prompt');self.assertTrue(r['keywords']);self.assertEqual(req.call_args.args[0].full_url,'https://api.anthropic.com/v1/messages')
class HTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.store=core.Store(Path(cls.tmp.name)/'http.db');cls.server=AppServer(('127.0.0.1',0),cls.store);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.url='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
 def req(self,path,data=None,headers=None):
  h={'Content-Type':'application/json','X-Pets-CSRF':self.server.csrf};h.update(headers or {});r=urllib.request.Request(self.url+path,json.dumps(data).encode() if data is not None else None,h);return urllib.request.urlopen(r,timeout=10)
 def test_bootstrap(self):
  with self.req('/api/bootstrap') as r:self.assertTrue(json.load(r)['csrf'])
 def test_csrf(self):
  with self.assertRaises(urllib.error.HTTPError) as c:self.req('/api/article/save',{'data':core.empty_article()}, {'X-Pets-CSRF':'bad'})
  self.assertEqual(c.exception.code,403)
 def test_origin(self):
  with self.assertRaises(urllib.error.HTTPError) as c:self.req('/api/article/save',{'data':core.empty_article()},{'Origin':'https://evil.example'})
  self.assertEqual(c.exception.code,403)
 def test_invalid_host(self):
  with self.assertRaises(urllib.error.HTTPError) as c:self.req('/api/bootstrap',headers={'Host':'evil.example'})
  self.assertEqual(c.exception.code,403)
 def test_static_traversal(self):
  with self.assertRaises(urllib.error.HTTPError):self.req('/../core.py')
 def test_secret_not_persisted(self):
  payload={'provider':'openai','model':'TEST','min_chars':6000,'max_chars':8000,'consent':False,'api_key':'TEST-SECRET-DO-NOT-STORE'}
  with self.req('/api/settings',payload) as r:self.assertNotIn('TEST-SECRET',r.read().decode())
  with self.req('/api/backup') as r:self.assertNotIn('TEST-SECRET',r.read().decode())
  self.assertNotIn(b'TEST-SECRET',self.store.path.read_bytes())
 def test_local_generation(self):
  a=core.empty_article();a['topic']='Отдых собаки'
  with self.req('/api/generate',{'data':a,'task':'titles','mode':'local'}) as r:self.assertEqual(json.load(r)['mode'],'local')
 def test_article_crud(self):
  with self.req('/api/article/save',{'data':core.empty_article()}) as r:v=json.load(r)
  with self.req('/api/article/'+v['id']) as r:self.assertEqual(json.load(r)['revision'],1)
 def test_headers(self):
  with self.req('/') as r:self.assertEqual(r.headers['X-Frame-Options'],'DENY');self.assertIn("script-src 'self'",r.headers['Content-Security-Policy'])
 def test_export(self):
  id=self.store.list_articles()[0]['id']
  with self.req('/api/export?id='+id) as r:self.assertEqual(r.headers['Content-Type'],'application/zip');self.assertTrue(r.read().startswith(b'PK'))
if __name__=='__main__':unittest.main()
