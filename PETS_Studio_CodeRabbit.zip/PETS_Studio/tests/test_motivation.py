import tempfile
import unittest
from pathlib import Path

from core import Problem, Store


class MotivationTests(unittest.TestCase):
    def test_motivation_defaults_are_available_for_old_projects(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'pets.sqlite3')
            motivation = store.settings()['motivation']
            self.assertEqual(motivation['season_days'], 30)
            self.assertEqual(motivation['target_articles'], 8)
            self.assertEqual(motivation['sessions_done'], 0)

    def test_motivation_roundtrip_is_clamped_and_keeps_project_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'pets.sqlite3')
            store.save_settings({
                'motivation': {
                    'season_name': '  Мой сезон  ',
                    'season_days': 999,
                    'target_articles': 0,
                    'target_sessions': 999,
                    'sessions_done': 14,
                    'last_session': '2026-11-14',
                    'step_done': True,
                }
            })
            motivation = store.settings()['motivation']
            self.assertEqual(motivation['season_name'], 'Мой сезон')
            self.assertEqual(motivation['season_days'], 90)
            self.assertEqual(motivation['target_articles'], 1)
            self.assertEqual(motivation['target_sessions'], 200)
            self.assertEqual(motivation['sessions_done'], 14)
            self.assertTrue(motivation['step_done'])
            self.assertEqual(store.list_articles()[0]['title'], 'Лежанка пустует, а собака спит рядом')

    def test_motivation_rejects_non_mapping(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'pets.sqlite3')
            with self.assertRaises(Problem):
                store.save_settings({'motivation': 'не настройки'})


if __name__ == '__main__':
    unittest.main()
