import json
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch
import core
import topic_engine
import test_service


def idea(title='Как подготовить прихожую к возвращению с прогулки'):
    return {'title_working': title, 'reader_question': 'Что убрать с прохода?',
            'promise': 'Понятная бытовая проверка', 'rubric': 'HOME', 'risk': 'GREEN'}


class TopicEngineTests(unittest.TestCase):
    def test_rejects_reworded_duplicate(self):
        self.assertTrue(topic_engine.similar('Как подготовить прихожую к возвращению с прогулки',
                                            'К возвращению с прогулки: как подготовить прихожую?'))
        self.assertEqual(topic_engine.fresh([idea()], [idea()['title_working']]), [])

    def test_malformed_batch_is_rejected_whole(self):
        with self.assertRaises(core.Problem): topic_engine.validate({'topics':[idea(), {'title_working':'Ошибка'}]})

    def test_prompt_has_project_and_archive_without_claiming_demand(self):
        text = topic_engine.prompt('лежанка', 'ПРОЕКТ-TEST', [idea()], [{'title':'Архив-TEST','topic':'Отдых'}])
        for value in ('ПРОЕКТ-TEST', 'Архив-TEST', 'лежанка', 'Не выдумывай спрос'): self.assertIn(value, text)

    def test_bank_cycles_without_repeats_and_persists(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'test.db'; store = core.Store(path); seen = set()
            while True:
                rows = topic_engine.local('', store.topics(), store.list_articles(), store.topic_offers())
                if not rows: break
                ids = {row['id'] for row in rows}; self.assertFalse(seen & ids); seen |= ids
                store.offer_topics(rows)
                store = core.Store(path)
            self.assertGreater(len(seen), 12)
            self.assertEqual(topic_engine.local('', store.topics(), store.list_articles(), store.topic_offers()), [])

    def test_generated_topic_is_saved_in_full_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'test.db'; store = core.Store(path)
            rows = topic_engine.validate({'topics':[idea()]});store.offer_topics(rows,generated=True)
            reopened = core.Store(path)
            self.assertIn(rows[0]['id'], reopened.topic_offers())
            self.assertIn(rows[0], reopened.topics())

    def test_short_text_is_advice_but_empty_and_clinical_still_block(self):
        a=core.empty_article();a['title']='Отдых';a['body']='Автор описал своё наблюдение.';a['gates'].update(facts=True,safety=True,rights=True)
        self.assertTrue(core.qc(a)['can_approve'])
        self.assertEqual(next(i for i in core.qc(a)['issues'] if i['code']=='LENGTH')['level'], 'REVIEW')
        a['body']='';self.assertFalse(core.qc(a)['can_approve'])
        a['body']='Давайте 5 мг/кг.';self.assertFalse(core.qc(a)['can_approve'])

    def test_asset_change_keeps_facts_but_resets_rights(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=core.Store(Path(tmp)/'test.db');a=core.empty_article();a['gates'].update(facts=True,safety=True,rights=True)
            saved=store.save(None,a);a['cover']['description']='Новое фото'
            changed=store.save(saved['id'],a,saved['revision'])['data']
            self.assertTrue(changed['gates']['facts']);self.assertTrue(changed['gates']['safety']);self.assertFalse(changed['gates']['rights'])


class TopicHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): test_service.HTTPTests.setUpClass.__func__(cls)
    @classmethod
    def tearDownClass(cls): test_service.HTTPTests.tearDownClass.__func__(cls)
    req=test_service.HTTPTests.req

    def test_local_does_not_call_provider_and_next_batch_differs(self):
        with patch('app.call_provider') as provider:
            with self.req('/api/topic/new', {'mode':'local'}) as response:a=json.load(response)['topics']
            with self.req('/api/topic/new', {'mode':'local'}) as response:b=json.load(response)['topics']
            self.assertTrue(a);self.assertTrue(b);self.assertFalse({t['id'] for t in a}&{t['id'] for t in b});provider.assert_not_called()

    def test_ai_generates_and_saves_then_rejects_repeat(self):
        with patch('app.call_provider', return_value={'topics':[idea()]}) as provider:
            with self.req('/api/topic/new', {'mode':'ai','query':'дом'}) as response:first=json.load(response)
            self.assertEqual(len(first['topics']),1)
            with self.req('/api/topic/new', {'mode':'ai','query':'дом'}) as response:second=json.load(response)
            self.assertEqual(second['topics'],[])
            self.assertIn('АКТИВНЫЕ ИНСТРУКЦИИ',provider.call_args.args[2])

    def test_ai_error_preserves_bank_and_offers(self):
        old=self.store.topics();offered=self.store.topic_offers()
        with patch('app.call_provider',side_effect=core.Problem('TEST error')):
            with self.assertRaises(urllib.error.HTTPError):self.req('/api/topic/new',{'mode':'ai'})
        self.assertEqual(old,self.store.topics());self.assertEqual(offered,self.store.topic_offers())

    def test_pipeline_without_sources_reaches_provider(self):
        with patch('app.call_provider',return_value={'hold':True,'text':'Нужны уточнения'}) as provider:
            with self.req('/api/pipeline',{'data':core.empty_article(),'mode':'ai'}) as response:result=json.load(response)
            self.assertIn('article',result['stages']);self.assertNotIn('preflight',result['stages']);self.assertTrue(provider.called)
