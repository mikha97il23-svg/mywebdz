/* Studio 3: real offline helpers, explicit external requests, manual chat handoff. */
function downloadJSON(name,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=el('a',{href:url,download:name});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function currentText(){return S.item?$('body').value:'';}
function renderTopicSuggestions(r){
 const box=$('topic-suggestions');box.hidden=false;$('hide-topics').hidden=false;$('topic').setAttribute('aria-expanded','true');
 const note=r.research_count?`${r.method} Источников в срезе: ${r.research_count}.`:`${r.method}`;
 box.replaceChildren(el('p',{class:'small muted',text:note}));
 for(const t of r.topics){
  const tags=[];
  if(t.risk==='AMBER')tags.push(el('span',{class:'topic-score risk',text:'Нужна профильная проверка'}));
  const source=t.research_examples?.[0];
  const children=[el('strong',{text:t.title_working}),el('small',{text:t.reader_question||t.promise||t.reason}),el('span',{class:'topic-score-row'},tags)];
  if(source?.title)children.push(el('small',{class:'topic-source',text:'Сигнал: '+source.title}));
  const row=el('div',{class:'topic-option-wrap'},[el('button',{class:'topic-option',type:'button',onclick:protect(()=>selectTopic(t))},[el('span',{class:'option-index',text:t.origin==='ai'?'ИИ':'Идея'}),el('span',{},children)])]);
  if(source?.link)row.append(el('a',{class:'topic-source-link',href:source.link,target:'_blank',rel:'noreferrer',text:'Источник ↗'}));
  box.append(row);
 }
 if(!r.topics.length)box.append(el('button',{class:'button',text:'Открыть сохранённые темы',onclick:protect(()=>go('topics'))}));
}
async function getSuggestions(){
 if(S.topicBusy)return;
 const mode=$('generation-mode').value;
 if(mode==='ai'&&(!S.boot.api_configured||!S.boot.settings.consent||!S.boot.settings.model)){await go('settings');toast('Подключите ИИ и сохраните согласие для создания новых тем.');return;}
 if(mode==='ai'&&!confirm('Создать новые темы по активным инструкциям проекта? Направление, названия сохранённых тем и материалов, записанные показы и открытия будут переданы ИИ. Запрос может быть платным.'))return;
 const q=$('topic').value,id=S.item?.id,seq=++S.suggestionSeq,button=$('suggest-topic'),box=$('topic-suggestions');
 S.topicBusy=true;button.disabled=true;button.textContent='Готовлю идеи…';box.hidden=false;box.replaceChildren(el('p',{class:'small muted',text:mode==='ai'?'Создаю новые идеи по правилам проекта…':'Выбираю ещё не показанные идеи из банка…'}));
 try{
  const r=await api('/api/topic/new',{query:q,mode});await refresh();
  if(seq===S.suggestionSeq&&id===S.item?.id&&q===$('topic').value)renderTopicSuggestions(r);
 }catch(e){if(seq===S.suggestionSeq)box.replaceChildren(el('p',{text:e.message}));throw e;}
 finally{S.topicBusy=false;button.disabled=false;button.textContent='Новые темы';}
}
function hideSuggestions(){clearTimeout(S.topicTimer);S.suggestionSeq++;$('topic-suggestions').hidden=true;$('hide-topics').hidden=true;$('topic').setAttribute('aria-expanded','false');}
async function selectTopic(t){$('topic').value=t.title_working;if(!$('body').value.trim()&&['Новый материал',''].includes($('title').value.trim()))$('title').value=t.title_working;$('brief-reader_problem').value=t.reader_question||t.title_working;$('brief-promise').value=t.promise||'';$('brief-rubric').value=({HEALTH:'CARE',AGE:'CARE',GEAR:'CHOICE',FOOD:'CARE'})[t.rubric]||(['HOME','WALK','CARE','CHOICE','STORY','BEHAVIOR'].includes(t.rubric)?t.rubric:'HOME');if(t.risk==='AMBER'){$('requires-expert').checked=true;$('expert-fields').hidden=false;}hideSuggestions();markDirty();if($('auto-profile').checked)await updateProfile(true,'local');await save();toast('Тема подставлена в текущий материал. Текст не заменён; спрос остаётся гипотезой.');}
function applyProfile(r){for(const k of ['audience','format','tone'])$(k).value=r[k];$('profile-note').textContent=(r.mode==='ai'?'ИИ-профиль':'Автопрофиль · локальные правила')+' / '+(r.basis==='body'?'по телу статьи':r.mode==='ai'?'по переданному тексту':'по теме')+'. '+r.reasons.join('. ')+'. Можно исправить вручную.';markDirty();}
async function updateProfile(explicit=false,forcedMode=null){if(!S.item||(!explicit&&!$('auto-profile').checked))return;const a=formData(),id=S.item.id,body=a.body,topic=a.topic;const seq=++S.profileSeq;const mode=forcedMode||'local';const r=await api('/api/profile',{data:a,mode});if(id!==S.item?.id||seq!==S.profileSeq||body!==currentText()||topic!==$('topic').value)return;if(!explicit&&!$('auto-profile').checked)return;applyProfile(r);}
async function openHandoff(){await save();$('handoff-dialog').showModal();}
async function prepareHandoff(){await save();const r=await api('/api/handoff',{data:formData(),task:$('handoff-task').value});$('handoff-prompt').value=r.prompt;toast('Задание готово. Проверьте личные данные, затем скопируйте в отдельный чат.');}
async function previewHandoff(){const raw=$('handoff-response').value;if(!raw.trim())throw Error('Вставьте ответ чата.');S.handoff=await api('/api/handoff/parse',{text:raw});S.handoffRaw=raw;S.handoffArticle=S.item.id;S.handoffTask=$('handoff-task').value;const box=$('handoff-preview');box.hidden=false;box.replaceChildren(el('p',{text:S.handoff.hold?'HOLD: чат запросил данные. Текст не будет заменён.':'Предварительный просмотр. Подтверждения источников, прав и допуска не импортируются.'}),el('pre',{class:'handoff-pre',text:JSON.stringify(S.handoff,null,2)}));$('apply-handoff').hidden=!!S.handoff.hold;if(Array.isArray(S.handoff.titles)){$('apply-handoff').hidden=true;for(const title of S.handoff.titles)box.append(el('button',{class:'result-item',text:title,onclick:()=>{S.handoff={title};$('apply-handoff').hidden=false;toast('Заголовок выбран для импорта');}}));}}
async function applyHandoff(){if(!S.handoff||S.handoffArticle!==S.item.id||S.handoffRaw!==$('handoff-response').value||S.handoffTask!==$('handoff-task').value)throw Error('Ответ, задача или материал изменились. Повторите просмотр.');const r=S.handoff;if(r.hold)return;if(['review','outline'].includes(S.handoffTask)){if(typeof r.text!=='string')throw Error('В ответе нет текста.');$('generation-result').hidden=false;renderGeneration(S.handoffTask,{result:r,notice:'Ответ внешнего чата. Сохраните нужное вручную; это не статья и не допуск.'});$('handoff-dialog').close();return;}
if(r.text&&['article','rewrite'].includes(S.handoffTask)){if(!confirm('Заменить текст? Предыдущая сохранённая версия останется в истории. Все допуски потребуют повторной проверки.'))return;await save();$('body').value=r.text;}
else if(r.text&&!r.title&&!r.keywords&&!r.audience)throw Error('Для этой задачи нужен структурированный JSON. Обычный текст можно импортировать как статью/переработку.');
if(r.title)$('title').value=r.title;if(r.keywords){S.item.data.keywords=r.keywords;renderKeywords();}if(r.titles)throw Error('Используйте объект с title либо выберите заголовок вручную.');if(r.audience&&r.tone&&r.format){applyProfile({...r,mode:'ai',reasons:['Профиль из отдельного чата']});$('auto-profile').checked=false;}
markDirty();if(r.text&&$('auto-profile').checked)await updateProfile(true,'local');await save();$('handoff-dialog').close();toast('Ответ применён. Источники и объём не подтверждены автоматически.');}
async function runStyle(){await save();const text=currentText(),id=S.item.id;const r=await api('/api/style',{data:formData()});if(id!==S.item.id||text!==currentText())return;const box=$('style-result');box.hidden=false;box.replaceChildren(el('h3',{text:r.status}),el('strong',{text:r.author_verdict}),el('p',{class:'small muted',text:r.scope}));for(const x of r.issues)box.append(el('div',{class:'audit-finding'},[el('strong',{text:x.kind}),el('p',{text:'«'+x.fragment+'»'}),el('p',{text:x.advice})]));}
async function runDetector(){if(!S.boot.detector_configured)throw Error('Сначала подключите отдельный API-ключ Copyleaks в настройках. Локальная проверка шаблонности доступна без него.');const sandbox=$('detector-sandbox').checked;if(!confirm(sandbox?'Отправить текст Copyleaks в sandbox? Это тест интеграции, не оценка авторства.':'Отправить текст Copyleaks? Проверка может списать кредиты провайдера.'))return;await save();const text=currentText(),id=S.item.id;const btn=$('run-detector');btn.disabled=true;$('detector-result').hidden=false;$('detector-result').replaceChildren(el('p',{text:'Ожидаю внешний сервис… Автоматического повтора нет.'}));try{const r=await api('/api/detector/check',{data:formData(),sandbox});if(id!==S.item.id||text!==currentText()){$('detector-result').replaceChildren(el('p',{text:'Текст изменился во время запроса. Полученный результат к нему уже не относится.'}));return;}S.detectorText=text;const box=$('detector-result');box.replaceChildren(el('h3',{text:r.status}),el('p',{text:'Модель: '+r.model_version}),el('p',{text:'Показатели сервиса (шкала 0–1): summary.ai = '+r.summary.ai+'; summary.human = '+r.summary.human}),el('p',{text:r.scope}),el('p',{class:'small muted',text:'Это не процент доказанного авторства и не результат модерации Дзена.'}),el('button',{class:'button',text:'Скачать ответ детектора',onclick:()=>downloadJSON('PETS_DETECTOR_REPORT.json',r)}));}catch(e){$('detector-result').replaceChildren(el('p',{text:e.message}));throw e;}finally{btn.disabled=false;}}
function initV3(){S.profileSeq=0;S.suggestionSeq=0;$('suggest-topic').onclick=protect(getSuggestions);$('hide-topics').onclick=hideSuggestions;$('topic').addEventListener('input',()=>{clearTimeout(S.topicTimer);S.suggestionSeq++;hideSuggestions();scheduleProfile();});$('topic').addEventListener('keydown',e=>{if(e.key==='Escape')hideSuggestions();if(e.key==='ArrowDown'&&!$('topic-suggestions').hidden){e.preventDefault();$('topic-suggestions').querySelector('button')?.focus();}});$('topic-suggestions').addEventListener('keydown',e=>{const buttons=[...$('topic-suggestions').querySelectorAll('button')];let i=buttons.indexOf(document.activeElement);if(e.key==='Escape'){hideSuggestions();$('topic').focus();}if(['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}});
function scheduleProfile(){clearTimeout(S.profileTimer);S.profileSeq++;if($('auto-profile').checked)S.profileTimer=setTimeout(()=>updateProfile(false,'local').catch(fail),1100);}
$('body').addEventListener('input',()=>{scheduleProfile();clearTimeout(S.qcTimer);S.qcTimer=setTimeout(()=>runQC().catch(fail),2200);if(S.detectorText&&S.detectorText!==currentText())$('detector-result').replaceChildren(el('p',{text:'Текст изменён. Прежняя оценка детектора устарела; повторите запрос при необходимости.'}));$('style-result').hidden=true;});for(const k of ['audience','format','tone'])$(k).addEventListener(k==='format'?'change':'input',()=>{$('auto-profile').checked=false;$('profile-note').textContent='Ручной профиль. Автоподбор выключен, чтобы не затереть вашу правку.';S.profileSeq++;});$('auto-profile').onchange=()=>{if($('auto-profile').checked)updateProfile(true,'local').catch(fail);};$('profile-now').onclick=protect(async()=>{const ai=$('generation-mode').value==='ai';if(ai&&!confirm('Запросить профиль у ИИ? Текст будет передан выбранному провайдеру, возможна оплата.'))return;await updateProfile(true,ai?'ai':'local');await save();});$('qc-second').onclick=protect(runQC);$('download-qc').onclick=protect(async()=>{const r=await runQC();if(r)downloadJSON('PETS_QC_REPORT.json',r);});$('show-audit').onclick=protect(()=>go('audit'));$('run-style').onclick=protect(runStyle);$('run-detector').onclick=protect(runDetector);$('open-handoff-global').onclick=protect(openHandoff);$('close-handoff').onclick=()=>$('handoff-dialog').close();$('prepare-handoff').onclick=protect(prepareHandoff);$('copy-handoff').onclick=protect(async()=>{if(!$('handoff-prompt').value)await prepareHandoff();await copy($('handoff-prompt').value);});$('preview-handoff').onclick=protect(previewHandoff);$('apply-handoff').onclick=protect(applyHandoff);$('handoff-response').oninput=()=>{$('apply-handoff').hidden=true;};$('handoff-task').onchange=()=>{$('handoff-prompt').value='';$('apply-handoff').hidden=true;};
$('save-detector').onclick=protect(async()=>{const r=await api('/api/detector/config',{email:$('detector-email').value,key:$('detector-key').value,consent:$('detector-consent').checked});S.boot.detector_configured=r.configured;$('detector-key').value='';$('detector-email').value='';$('detector-config-status').textContent=r.configured?'Подключён в памяти процесса. Реальный запрос ещё не выполнен.':'Не подключён';toast('Данные сохранены только в памяти сервера.');});$('forget-detector').onclick=protect(async()=>{await api('/api/detector/config',{forget:true});S.boot.detector_configured=false;$('detector-key').value='';$('detector-email').value='';$('detector-consent').checked=false;$('detector-config-status').textContent='Не подключён';toast('Данные детектора удалены из памяти сервера.');});
async function saveNotionConfig(){
 const token=$('notion-token').value.trim();
 const url=$('notion-database-url').value.trim();
 const r=await api('/api/notion/config',{token,database_url:url});
 S.boot.notion_configured=r.configured;S.boot.notion_database_url=r.database_url;
 $('notion-token').value='';renderSettings();return r;
}
async function notionTest(){
 if($('notion-token').value.trim())await saveNotionConfig();
 const box=$('notion-sync-result');box.hidden=false;box.replaceChildren(el('p',{class:'small muted',text:'Проверяю доступ к базе Notion…'}));
 try{const r=await api('/api/notion/test',{});
  box.replaceChildren(el('p',{class:'qc-line good',text:r.message+' '+r.title}));toast('Подключение Notion подтверждено');
 }catch(e){box.replaceChildren(el('p',{class:'qc-line bad',text:e.message}));throw e;}
}
async function notionSync(mode){
 await save();
 if($('notion-token').value.trim())await saveNotionConfig();
 const box=$('notion-sync-result');box.hidden=false;box.replaceChildren(el('p',{class:'small muted',text:'Синхронизация…'}));
 try{const r=await api('/api/notion/sync',{mode});
  await refresh();if(S.item)await load(S.item.id);renderSettings();
  const nodes=[el('p',{class:r.conflicts?.length?'qc-line':'qc-line good',text:r.message})];
  if(r.conflicts?.length)nodes.push(el('p',{class:'small muted',text:'Конфликты не перезаписаны: '+r.conflicts.join(', ')}));
  box.replaceChildren(...nodes);toast(r.conflicts?.length?'Синхронизация завершена с конфликтами':'Синхронизация завершена');
 }catch(e){box.replaceChildren(el('p',{class:'qc-line bad',text:e.message}));throw e;}
}
$('notion-backups').onclick=protect(async()=>{
 const box=$('notion-backups-result');box.hidden=false;
 const rows=await api('/api/notion/backups');
 box.replaceChildren(el('p',{class:'small muted',text:'Локальные копии содержат текст и свойства страницы. Восстановление заменяет текущее содержимое после создания ещё одной копии.'}));
 if(!rows.length){box.append(el('p',{text:'Копий пока нет.'}));return;}
 for(const row of rows){
  const download=el('a',{href:'/api/notion/backup?id='+encodeURIComponent(row.id),text:'Скачать JSON'});
  const restore=el('button',{class:'button',text:'Восстановить в Notion',onclick:protect(async()=>{
   if(!confirm('Восстановить страницу '+row.page_id+' из копии? Текущее содержимое будет заменено; сначала будет создана его копия.'))return;
   if($('notion-token').value.trim())await saveNotionConfig();
   const result=await api('/api/notion/restore',{id:row.id});toast(result.message);
  })});
  box.append(el('div',{class:'action-row'},[el('span',{text:row.created_at+' · '+row.page_id}),download,restore]));
 }
});
$('notion-test').onclick=protect(notionTest);$('notion-pull').onclick=protect(()=>notionSync('pull'));$('notion-push').onclick=protect(()=>notionSync('push'));$('notion-sync').onclick=protect(()=>notionSync('sync'));
$('notion-forget').onclick=protect(async()=>{await api('/api/notion/config',{forget:true});S.boot.notion_configured=false;$('notion-token').value='';renderSettings();const box=$('notion-sync-result');box.hidden=false;box.replaceChildren(el('p',{class:'small muted',text:'Токен удалён из памяти сервера. Ссылка на базу сохранена.'}));toast('Токен Notion удалён из памяти процесса.');});
const configured=!!S.boot.detector_configured;$('detector-config-status').textContent=configured?'Подключён в памяти процесса':'Не подключён';}
